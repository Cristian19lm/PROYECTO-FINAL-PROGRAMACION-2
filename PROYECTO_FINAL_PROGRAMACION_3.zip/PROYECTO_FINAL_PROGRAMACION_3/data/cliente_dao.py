import sqlite3
from typing import List
from data.database_manager import DatabaseManager
from data.excepciones import RegistroNoEncontradoError, traducir_integridad
from domain.cliente import Cliente

_COLUMNAS = "id_cliente, documento, nombre, telefono, email"


class ClienteDAO:
    """Patrón DAO para operaciones CRUD sobre la tabla clientes."""

    def __init__(self, db_manager: DatabaseManager):
        self.__db_manager = db_manager

    def insertar(self, cliente: Cliente) -> int:
        """Inserta el cliente y devuelve el id autoincremental asignado."""
        cliente.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO clientes (documento, nombre, telefono, email) VALUES (?, ?, ?, ?)",
                    (cliente.documento, cliente.nombre, cliente.telefono, cliente.email)
                )
                return cursor.lastrowid
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "documento", cliente.documento) from e

    def obtener_todos(self) -> List[Cliente]:
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute(f"SELECT {_COLUMNAS} FROM clientes ORDER BY id_cliente")
            return [Cliente.desde_tupla(row) for row in cursor.fetchall()]

    def actualizar(self, cliente: Cliente) -> None:
        cliente.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                cursor.execute(
                    "UPDATE clientes SET documento = ?, nombre = ?, telefono = ?, email = ? WHERE id_cliente = ?",
                    (cliente.documento, cliente.nombre, cliente.telefono, cliente.email, cliente.id_cliente)
                )
                if cursor.rowcount == 0:
                    raise RegistroNoEncontradoError("El cliente", cliente.id_cliente)
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "documento", cliente.documento) from e

    def eliminar(self, id_cliente: int) -> None:
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM clientes WHERE id_cliente = ?", (id_cliente,))
            if cursor.rowcount == 0:
                raise RegistroNoEncontradoError("El cliente", id_cliente)

    def contar_ventas(self, id_cliente: int) -> int:
        """Cantidad de ventas asociadas (se borrarían en cascada al eliminar el cliente)."""
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT COUNT(*) FROM ventas WHERE id_cliente = ?", (id_cliente,))
            return cursor.fetchone()[0]
