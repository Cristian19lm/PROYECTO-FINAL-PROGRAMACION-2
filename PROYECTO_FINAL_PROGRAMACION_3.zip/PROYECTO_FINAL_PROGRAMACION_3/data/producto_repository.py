import sqlite3
from typing import List
from data.database_manager import DatabaseManager
from data.excepciones import (
    RegistroNoEncontradoError, StockInsuficienteError, traducir_integridad
)
from domain.producto import Producto
from domain.venta import Venta

_COLUMNAS_PRODUCTO = "id_producto, codigo, nombre, categoria, precio, stock"


class ProductoRepository:
    """Patrón Repository para la gestión de productos y registro de ventas."""

    def __init__(self, db_manager: DatabaseManager):
        self.__db_manager = db_manager

    # ------------------------------------------------------------------ PRODUCTOS
    def insertar_producto(self, producto: Producto) -> int:
        """Inserta el producto y devuelve el id autoincremental asignado."""
        producto.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                cursor.execute(
                    "INSERT INTO productos (codigo, nombre, categoria, precio, stock) VALUES (?, ?, ?, ?, ?)",
                    (producto.codigo, producto.nombre, producto.categoria, producto.precio, producto.stock)
                )
                return cursor.lastrowid
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "código", producto.codigo) from e

    def obtener_productos(self) -> List[Producto]:
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute(f"SELECT {_COLUMNAS_PRODUCTO} FROM productos ORDER BY id_producto")
            return [Producto.desde_tupla(row) for row in cursor.fetchall()]

    def actualizar_producto(self, producto: Producto) -> None:
        producto.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                cursor.execute(
                    "UPDATE productos SET codigo = ?, nombre = ?, categoria = ?, precio = ?, stock = ? "
                    "WHERE id_producto = ?",
                    (producto.codigo, producto.nombre, producto.categoria, producto.precio,
                     producto.stock, producto.id_producto)
                )
                if cursor.rowcount == 0:
                    raise RegistroNoEncontradoError("El producto", producto.id_producto)
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "código", producto.codigo) from e

    def eliminar_producto(self, id_producto: int) -> None:
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("DELETE FROM productos WHERE id_producto = ?", (id_producto,))
            if cursor.rowcount == 0:
                raise RegistroNoEncontradoError("El producto", id_producto)

    def contar_ventas_producto(self, id_producto: int) -> int:
        """Cantidad de ventas asociadas (se borrarían en cascada al eliminar el producto)."""
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT COUNT(*) FROM ventas WHERE id_producto = ?", (id_producto,))
            return cursor.fetchone()[0]

    # --------------------------------------------------------------------- VENTAS
    @staticmethod
    def __descontar_stock(cursor: sqlite3.Cursor, id_producto: int, cantidad: int) -> None:
        """Verifica y descuenta stock dentro de la transacción en curso."""
        cursor.execute("SELECT nombre, stock FROM productos WHERE id_producto = ?", (id_producto,))
        fila = cursor.fetchone()
        if fila is None:
            raise RegistroNoEncontradoError("El producto", id_producto)
        if fila[1] < cantidad:
            raise StockInsuficienteError(fila[0], fila[1], cantidad)
        cursor.execute("UPDATE productos SET stock = stock - ? WHERE id_producto = ?", (cantidad, id_producto))

    def registrar_venta(self, venta: Venta) -> None:
        """Registra una venta y descuenta el stock de forma transaccional.

        Lanza StockInsuficienteError / RegistroNoEncontradoError si no se puede completar;
        en ese caso no se guarda nada (rollback automático).
        """
        venta.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                self.__descontar_stock(cursor, venta.id_producto, venta.cantidad)
                cursor.execute(
                    "INSERT INTO ventas (id_cliente, id_producto, cantidad, fecha, total) VALUES (?, ?, ?, ?, ?)",
                    (venta.id_cliente, venta.id_producto, venta.cantidad, venta.fecha, venta.total)
                )
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "venta", str(venta.id_venta)) from e

    def obtener_ventas(self) -> List[Venta]:
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT id_venta, id_cliente, id_producto, cantidad, fecha, total FROM ventas ORDER BY id_venta")
            return [Venta.desde_tupla(row) for row in cursor.fetchall()]

    def actualizar_venta(self, venta: Venta) -> None:
        """Modifica una venta: devuelve el stock anterior y descuenta el nuevo, todo en una transacción."""
        venta.validar()
        try:
            with self.__db_manager.obtener_conexion() as conexion:
                cursor = conexion.cursor()
                cursor.execute("SELECT id_producto, cantidad FROM ventas WHERE id_venta = ?", (venta.id_venta,))
                anterior = cursor.fetchone()
                if anterior is None:
                    raise RegistroNoEncontradoError("La venta", venta.id_venta)

                cursor.execute(
                    "UPDATE productos SET stock = stock + ? WHERE id_producto = ?", (anterior[1], anterior[0])
                )
                self.__descontar_stock(cursor, venta.id_producto, venta.cantidad)
                cursor.execute(
                    "UPDATE ventas SET id_cliente = ?, id_producto = ?, cantidad = ?, total = ? WHERE id_venta = ?",
                    (venta.id_cliente, venta.id_producto, venta.cantidad, venta.total, venta.id_venta)
                )
        except sqlite3.IntegrityError as e:
            raise traducir_integridad(e, "venta", str(venta.id_venta)) from e

    def eliminar_venta(self, id_venta: int) -> None:
        """Elimina una venta y devuelve las unidades al stock del producto."""
        with self.__db_manager.obtener_conexion() as conexion:
            cursor = conexion.cursor()
            cursor.execute("SELECT id_producto, cantidad FROM ventas WHERE id_venta = ?", (id_venta,))
            fila = cursor.fetchone()
            if fila is None:
                raise RegistroNoEncontradoError("La venta", id_venta)
            cursor.execute("UPDATE productos SET stock = stock + ? WHERE id_producto = ?", (fila[1], fila[0]))
            cursor.execute("DELETE FROM ventas WHERE id_venta = ?", (id_venta,))
