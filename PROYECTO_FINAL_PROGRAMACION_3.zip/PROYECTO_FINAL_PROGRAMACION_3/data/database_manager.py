import sqlite3
from pathlib import Path
from typing import Generator
from contextlib import contextmanager

RAIZ_PROYECTO = Path(__file__).resolve().parent.parent


class DatabaseManager:
    """Gestor de base de datos con patrón Context Manager y control de transacciones."""

    def __init__(self, nombre_db: str = "tienda_computo.db"):
        ruta = Path(nombre_db)
        # La BD vive siempre en la raíz del proyecto, sin importar desde dónde se ejecute main.py
        self.__nombre_db = str(ruta if ruta.is_absolute() else RAIZ_PROYECTO / ruta)
        self.inicializar_base_datos()

    @contextmanager
    def obtener_conexion(self) -> Generator[sqlite3.Connection, None, None]:
        """Gestor de contexto with para manejar conexiones, commit, rollback y cierre automático."""
        conexion = sqlite3.connect(self.__nombre_db)
        # Integridad referencial obligatoria requerida por la rúbrica
        conexion.execute("PRAGMA foreign_keys = ON;")
        try:
            yield conexion
            conexion.commit()
        except Exception as e:
            conexion.rollback()
            raise e
        finally:
            conexion.close()

    def inicializar_base_datos(self) -> None:
        """Crea las 3 tablas relacionales y migra bases de datos antiguas (sin documento/código)."""
        with self.obtener_conexion() as conexion:
            cursor = conexion.cursor()

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS clientes (
                    id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
                    documento TEXT NOT NULL,
                    nombre TEXT NOT NULL,
                    telefono TEXT NOT NULL,
                    email TEXT NOT NULL
                )
            """)

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS productos (
                    id_producto INTEGER PRIMARY KEY AUTOINCREMENT,
                    codigo TEXT NOT NULL,
                    nombre TEXT NOT NULL,
                    categoria TEXT NOT NULL,
                    precio REAL NOT NULL,
                    stock INTEGER NOT NULL
                )
            """)

            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ventas (
                    id_venta INTEGER PRIMARY KEY AUTOINCREMENT,
                    id_cliente INTEGER NOT NULL,
                    id_producto INTEGER NOT NULL,
                    cantidad INTEGER NOT NULL,
                    fecha TEXT NOT NULL,
                    total REAL NOT NULL,
                    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE CASCADE,
                    FOREIGN KEY (id_producto) REFERENCES productos(id_producto) ON DELETE CASCADE
                )
            """)

            # Migración: la BD anterior no tenía estas columnas
            self.__migrar_columna(cursor, "clientes", "documento", "id_cliente")
            self.__migrar_columna(cursor, "productos", "codigo", "id_producto")

            # Índices únicos (sin distinguir mayúsculas): impiden documentos/códigos repetidos
            cursor.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_clientes_documento "
                "ON clientes(documento COLLATE NOCASE)"
            )
            cursor.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_productos_codigo "
                "ON productos(codigo COLLATE NOCASE)"
            )

    @staticmethod
    def __migrar_columna(cursor: sqlite3.Cursor, tabla: str, columna: str, columna_id: str) -> None:
        """Agrega la columna si falta y rellena los registros viejos con su ID como valor inicial.

        Los nombres de tabla/columna son constantes del código (nunca datos del usuario),
        por eso es seguro interpolarlos; PRAGMA y ALTER TABLE no admiten marcadores '?'.
        """
        existentes = [fila[1] for fila in cursor.execute(f"PRAGMA table_info({tabla})")]
        if columna not in existentes:
            cursor.execute(f"ALTER TABLE {tabla} ADD COLUMN {columna} TEXT")
        cursor.execute(
            f"UPDATE {tabla} SET {columna} = CAST({columna_id} AS TEXT) "
            f"WHERE {columna} IS NULL OR TRIM({columna}) = ''"
        )
