import sqlite3


class ErrorDeNegocio(Exception):
    """Error esperado por una regla del negocio (se muestra al usuario como advertencia)."""


class CodigoDuplicadoError(ErrorDeNegocio):
    """Se intentó guardar un documento/código que ya pertenece a otro registro."""

    def __init__(self, etiqueta: str, valor: str):
        self.etiqueta = etiqueta
        self.valor = valor
        super().__init__(f"Ya existe un registro con {etiqueta} '{valor}'. Use uno diferente.")


class RegistroNoEncontradoError(ErrorDeNegocio):
    """El registro que se quiere editar/eliminar/referenciar ya no existe."""

    def __init__(self, entidad: str, identificador: object = None):
        detalle = f" (ID {identificador})" if identificador is not None else ""
        super().__init__(f"{entidad}{detalle} no existe o ya fue eliminado.")


class StockInsuficienteError(ErrorDeNegocio):
    """No hay unidades suficientes del producto para completar la operación."""

    def __init__(self, producto: str, disponible: int, solicitado: int):
        super().__init__(
            f"Stock insuficiente de '{producto}': disponibles {disponible}, solicitadas {solicitado}."
        )


def traducir_integridad(error: sqlite3.IntegrityError, etiqueta: str, valor: str) -> Exception:
    """Convierte un IntegrityError de SQLite en una excepción de negocio legible."""
    mensaje = str(error).upper()
    if "UNIQUE" in mensaje:
        return CodigoDuplicadoError(etiqueta, valor)
    if "FOREIGN KEY" in mensaje:
        return RegistroNoEncontradoError("El cliente o el producto seleccionado")
    return error
