import math
import flet as ft
from datetime import datetime
from data.database_manager import DatabaseManager
from data.cliente_dao import ClienteDAO
from data.producto_repository import ProductoRepository
from data.excepciones import CodigoDuplicadoError, ErrorDeNegocio
from domain.cliente import Cliente
from domain.producto import Producto
from domain.venta import Venta
from ui.components.dialogos import notificar, confirmar
from ui.components.acciones import celda_acciones


def leer_precio(texto: str) -> float:
    """Convierte el texto del campo a precio; lanza ValueError con mensaje claro."""
    try:
        valor = float((texto or "").strip())
    except ValueError:
        raise ValueError("El precio debe ser un número (use punto para los decimales).")
    if not math.isfinite(valor):
        raise ValueError("El precio debe ser un número válido.")
    return valor


def leer_entero(texto: str, nombre_campo: str) -> int:
    """Convierte el texto del campo a entero; lanza ValueError con mensaje claro."""
    try:
        return int((texto or "").strip())
    except ValueError:
        raise ValueError(f"{nombre_campo} debe ser un número entero.")


def main_view(page: ft.Page):
    page.title = "TechStore Manager - Sistema de Cómputo"
    page.vertical_alignment = ft.MainAxisAlignment.START
    page.padding = 20
    page.theme_mode = ft.ThemeMode.DARK

    db = DatabaseManager()
    cliente_dao = ClienteDAO(db)
    producto_repo = ProductoRepository(db)

    # Registro que se está editando en cada sección (None = modo "crear")
    edicion: dict[str, object | None] = {"cliente": None, "producto": None, "venta": None}

    def limpiar_error(campo: ft.TextField):
        """Quita el mensaje de error de un campo en cuanto el usuario lo vuelve a editar."""
        def _limpiar(e):
            if campo.error:
                campo.error = None
                page.update()
        return _limpiar

    # ------------------------------------------------------------------ TABLAS
    tabla_clientes = ft.DataTable(columns=[
        ft.DataColumn(ft.Text("ID")),
        ft.DataColumn(ft.Text("Documento")),
        ft.DataColumn(ft.Text("Nombre")),
        ft.DataColumn(ft.Text("Teléfono")),
        ft.DataColumn(ft.Text("Email")),
        ft.DataColumn(ft.Text("Acciones")),
    ], rows=[])

    tabla_productos = ft.DataTable(columns=[
        ft.DataColumn(ft.Text("ID")),
        ft.DataColumn(ft.Text("Código")),
        ft.DataColumn(ft.Text("Nombre")),
        ft.DataColumn(ft.Text("Categoría")),
        ft.DataColumn(ft.Text("Precio")),
        ft.DataColumn(ft.Text("Stock")),
        ft.DataColumn(ft.Text("Acciones")),
    ], rows=[])

    tabla_ventas = ft.DataTable(columns=[
        ft.DataColumn(ft.Text("ID Venta")),
        ft.DataColumn(ft.Text("Cliente")),
        ft.DataColumn(ft.Text("Producto")),
        ft.DataColumn(ft.Text("Cant")),
        ft.DataColumn(ft.Text("Fecha")),
        ft.DataColumn(ft.Text("Total")),
        ft.DataColumn(ft.Text("Acciones")),
    ], rows=[])

    # ------------------------------------------------------------ CAMPOS CLIENTES
    txt_cli_doc = ft.TextField(label="Documento / ID del cliente *", width=220, hint_text="Cédula o NIT")
    txt_cli_nombre = ft.TextField(label="Nombre Completo *", width=300)
    txt_cli_tel = ft.TextField(label="Teléfono *", width=200)
    txt_cli_email = ft.TextField(label="Correo Electrónico", width=300)
    txt_cli_doc.on_change = limpiar_error(txt_cli_doc)
    lbl_estado_cli = ft.Text("", color=ft.Colors.AMBER_400, visible=False)

    # ----------------------------------------------------------- CAMPOS PRODUCTOS
    txt_prod_codigo = ft.TextField(label="Código del producto *", width=200, hint_text="SKU / referencia")
    txt_prod_nombre = ft.TextField(label="Nombre del Producto *", width=300)
    dd_prod_cat = ft.Dropdown(
        label="Categoría *",
        width=250,
        options=[
            ft.dropdown.Option("Computador"),
            ft.dropdown.Option("Impresora"),
            ft.dropdown.Option("Mouse Inalámbrico"),
            ft.dropdown.Option("Celular"),
        ]
    )
    txt_prod_precio = ft.TextField(label="Precio Unitario ($) *", width=170, keyboard_type=ft.KeyboardType.NUMBER)
    txt_prod_stock = ft.TextField(label="Stock *", width=120, keyboard_type=ft.KeyboardType.NUMBER)
    txt_prod_codigo.on_change = limpiar_error(txt_prod_codigo)
    lbl_estado_prod = ft.Text("", color=ft.Colors.AMBER_400, visible=False)

    # -------------------------------------------------------------- CAMPOS VENTAS
    dd_venta_cli = ft.Dropdown(label="Cliente *", width=320, options=[])
    dd_venta_prod = ft.Dropdown(label="Producto *", width=380, options=[])
    txt_venta_cant = ft.TextField(label="Cantidad *", width=120, keyboard_type=ft.KeyboardType.NUMBER)
    lbl_estado_venta = ft.Text("", color=ft.Colors.AMBER_400, visible=False)

    # ------------------------------------------------------------ CARGA DE DATOS
    def cargar_datos():
        clientes = cliente_dao.obtener_todos()
        productos = producto_repo.obtener_productos()
        ventas = producto_repo.obtener_ventas()
        cli_por_id = {c.id_cliente: c for c in clientes}
        prod_por_id = {p.id_producto: p for p in productos}

        tabla_clientes.rows.clear()
        for c in clientes:
            tabla_clientes.rows.append(ft.DataRow(cells=[
                ft.DataCell(ft.Text(str(c.id_cliente))),
                ft.DataCell(ft.Text(c.documento)),
                ft.DataCell(ft.Text(c.nombre)),
                ft.DataCell(ft.Text(c.telefono)),
                ft.DataCell(ft.Text(c.email)),
                celda_acciones(
                    on_editar=lambda e, c=c: editar_cliente(c),
                    on_eliminar=lambda e, c=c: pedir_eliminar_cliente(c),
                ),
            ]))

        tabla_productos.rows.clear()
        for p in productos:
            tabla_productos.rows.append(ft.DataRow(cells=[
                ft.DataCell(ft.Text(str(p.id_producto))),
                ft.DataCell(ft.Text(p.codigo)),
                ft.DataCell(ft.Text(p.nombre)),
                ft.DataCell(ft.Text(p.categoria)),
                ft.DataCell(ft.Text(f"${p.precio:,.2f}")),
                ft.DataCell(ft.Text(str(len(p)), color=ft.Colors.RED_300 if len(p) == 0 else None)),
                celda_acciones(
                    on_editar=lambda e, p=p: editar_producto(p),
                    on_eliminar=lambda e, p=p: pedir_eliminar_producto(p),
                ),
            ]))

        tabla_ventas.rows.clear()
        for v in ventas:
            cli = cli_por_id.get(v.id_cliente)
            prod = prod_por_id.get(v.id_producto)
            tabla_ventas.rows.append(ft.DataRow(cells=[
                ft.DataCell(ft.Text(str(v.id_venta))),
                ft.DataCell(ft.Text(f"{cli.documento} - {cli.nombre}" if cli is not None else f"ID {v.id_cliente}")),
                ft.DataCell(ft.Text(f"{prod.codigo} - {prod.nombre}" if prod is not None else f"ID {v.id_producto}")),
                ft.DataCell(ft.Text(str(v.cantidad))),
                ft.DataCell(ft.Text(v.fecha)),
                ft.DataCell(ft.Text(f"${v.total:,.2f}")),
                celda_acciones(
                    on_editar=lambda e, v=v: editar_venta(v),
                    on_eliminar=lambda e, v=v: pedir_eliminar_venta(v),
                ),
            ]))

        # Los desplegables de ventas se refrescan con los clientes/productos actuales
        dd_venta_cli.options = [
            ft.dropdown.Option(key=str(c.id_cliente), text=f"{c.documento} - {c.nombre}") for c in clientes
        ]
        dd_venta_prod.options = [
            ft.dropdown.Option(key=str(p.id_producto), text=f"{p.codigo} - {p.nombre} (stock {len(p)})")
            for p in productos
        ]
        if dd_venta_cli.value not in {str(c.id_cliente) for c in clientes}:
            dd_venta_cli.value = None
        if dd_venta_prod.value not in {str(p.id_producto) for p in productos}:
            dd_venta_prod.value = None
        page.update()

    # ================================================================== CLIENTES
    def limpiar_form_cliente(e=None):
        edicion["cliente"] = None
        for campo in (txt_cli_doc, txt_cli_nombre, txt_cli_tel, txt_cli_email):
            campo.value = ""
            campo.error = None
        btn_guardar_cli.content = "Guardar Cliente"
        btn_guardar_cli.icon = ft.Icons.SAVE
        btn_cancelar_cli.visible = False
        lbl_estado_cli.visible = False
        page.update()

    def editar_cliente(c: Cliente):
        edicion["cliente"] = c
        txt_cli_doc.value = c.documento
        txt_cli_nombre.value = c.nombre
        txt_cli_tel.value = c.telefono
        txt_cli_email.value = c.email
        txt_cli_doc.error = None
        btn_guardar_cli.content = "Actualizar Cliente"
        btn_guardar_cli.icon = ft.Icons.UPDATE
        btn_cancelar_cli.visible = True
        lbl_estado_cli.value = f"Editando cliente ID {c.id_cliente}. Modifique los datos y pulse Actualizar."
        lbl_estado_cli.visible = True
        page.update()

    def guardar_cliente(e):
        editando: Cliente | None = edicion["cliente"]
        try:
            cli = Cliente(editando.id_cliente if editando is not None else None,
                          txt_cli_doc.value, txt_cli_nombre.value, txt_cli_tel.value, txt_cli_email.value)
            if editando is not None:
                cliente_dao.actualizar(cli)
                mensaje = "Cliente actualizado correctamente"
            else:
                cliente_dao.insertar(cli)
                mensaje = "Cliente registrado exitosamente"
        except CodigoDuplicadoError as ex:
            txt_cli_doc.error = "Este documento ya está registrado"
            notificar(page, str(ex), "aviso")
            page.update()
            return
        except (ValueError, ErrorDeNegocio) as ex:
            notificar(page, str(ex), "error")
            return
        except Exception as ex:
            notificar(page, f"Error inesperado al guardar el cliente: {ex}", "error")
            return
        limpiar_form_cliente()
        cargar_datos()
        notificar(page, mensaje)

    def pedir_eliminar_cliente(c: Cliente):
        ventas = cliente_dao.contar_ventas(c.id_cliente)
        mensaje = f"¿Eliminar al cliente '{c.nombre}' (Doc: {c.documento})?"
        if ventas:
            mensaje += f"\n\nATENCIÓN: también se eliminarán {ventas} venta(s) asociadas a este cliente."

        def ejecutar():
            try:
                cliente_dao.eliminar(c.id_cliente)
            except ErrorDeNegocio as ex:
                notificar(page, str(ex), "error")
                cargar_datos()
                return
            except Exception as ex:
                notificar(page, f"No se pudo eliminar el cliente: {ex}", "error")
                return
            if edicion["cliente"] == c:
                limpiar_form_cliente()
            cargar_datos()
            notificar(page, "Cliente eliminado")

        confirmar(page, "Eliminar cliente", mensaje, ejecutar)

    btn_guardar_cli = ft.Button("Guardar Cliente", on_click=guardar_cliente, icon=ft.Icons.SAVE)
    btn_cancelar_cli = ft.OutlinedButton("Cancelar edición", on_click=limpiar_form_cliente,
                                         icon=ft.Icons.CLOSE, visible=False)

    # ================================================================ PRODUCTOS
    def limpiar_form_producto(e=None):
        edicion["producto"] = None
        for campo in (txt_prod_codigo, txt_prod_nombre, txt_prod_precio, txt_prod_stock):
            campo.value = ""
            campo.error = None
        dd_prod_cat.value = None
        btn_guardar_prod.content = "Guardar Producto"
        btn_guardar_prod.icon = ft.Icons.ADD_SHOPPING_CART
        btn_cancelar_prod.visible = False
        lbl_estado_prod.visible = False
        page.update()

    def editar_producto(p: Producto):
        edicion["producto"] = p
        txt_prod_codigo.value = p.codigo
        txt_prod_nombre.value = p.nombre
        dd_prod_cat.value = p.categoria
        txt_prod_precio.value = str(p.precio)
        txt_prod_stock.value = str(p.stock)
        txt_prod_codigo.error = None
        btn_guardar_prod.content = "Actualizar Producto"
        btn_guardar_prod.icon = ft.Icons.UPDATE
        btn_cancelar_prod.visible = True
        lbl_estado_prod.value = f"Editando producto ID {p.id_producto}. Modifique los datos y pulse Actualizar."
        lbl_estado_prod.visible = True
        page.update()

    def guardar_producto(e):
        editando: Producto | None = edicion["producto"]
        try:
            prod = Producto(
                editando.id_producto if editando is not None else None,
                txt_prod_codigo.value,
                txt_prod_nombre.value,
                dd_prod_cat.value,
                leer_precio(txt_prod_precio.value),
                leer_entero(txt_prod_stock.value, "El stock"),
            )
            if editando is not None:
                producto_repo.actualizar_producto(prod)
                mensaje = "Producto actualizado correctamente"
            else:
                producto_repo.insertar_producto(prod)
                mensaje = "Producto registrado exitosamente"
        except CodigoDuplicadoError as ex:
            txt_prod_codigo.error = "Este código ya está registrado"
            notificar(page, str(ex), "aviso")
            page.update()
            return
        except (ValueError, ErrorDeNegocio) as ex:
            notificar(page, str(ex), "error")
            return
        except Exception as ex:
            notificar(page, f"Error inesperado al guardar el producto: {ex}", "error")
            return
        limpiar_form_producto()
        cargar_datos()
        notificar(page, mensaje)

    def pedir_eliminar_producto(p: Producto):
        ventas = producto_repo.contar_ventas_producto(p.id_producto)
        mensaje = f"¿Eliminar el producto '{p.nombre}' (Código: {p.codigo})?"
        if ventas:
            mensaje += f"\n\nATENCIÓN: también se eliminarán {ventas} venta(s) de este producto."

        def ejecutar():
            try:
                producto_repo.eliminar_producto(p.id_producto)
            except ErrorDeNegocio as ex:
                notificar(page, str(ex), "error")
                cargar_datos()
                return
            except Exception as ex:
                notificar(page, f"No se pudo eliminar el producto: {ex}", "error")
                return
            if edicion["producto"] == p:
                limpiar_form_producto()
            cargar_datos()
            notificar(page, "Producto eliminado")

        confirmar(page, "Eliminar producto", mensaje, ejecutar)

    btn_guardar_prod = ft.Button("Guardar Producto", on_click=guardar_producto, icon=ft.Icons.ADD_SHOPPING_CART)
    btn_cancelar_prod = ft.OutlinedButton("Cancelar edición", on_click=limpiar_form_producto,
                                          icon=ft.Icons.CLOSE, visible=False)

    # ================================================================== VENTAS
    def limpiar_form_venta(e=None):
        edicion["venta"] = None
        dd_venta_cli.value = None
        dd_venta_prod.value = None
        txt_venta_cant.value = ""
        txt_venta_cant.error = None
        btn_vender.content = "Procesar Venta"
        btn_vender.icon = ft.Icons.POINT_OF_SALE
        btn_cancelar_venta.visible = False
        lbl_estado_venta.visible = False
        page.update()

    def editar_venta(v: Venta):
        edicion["venta"] = v
        dd_venta_cli.value = str(v.id_cliente)
        dd_venta_prod.value = str(v.id_producto)
        txt_venta_cant.value = str(v.cantidad)
        btn_vender.content = "Actualizar Venta"
        btn_vender.icon = ft.Icons.UPDATE
        btn_cancelar_venta.visible = True
        lbl_estado_venta.value = (f"Editando venta #{v.id_venta}. El stock se reajusta automáticamente "
                                  "y el total se recalcula con el precio actual.")
        lbl_estado_venta.visible = True
        page.update()

    def guardar_venta(e):
        editando: Venta | None = edicion["venta"]
        try:
            if not dd_venta_cli.value:
                raise ValueError("Seleccione un cliente (si no hay ninguno, regístrelo primero).")
            if not dd_venta_prod.value:
                raise ValueError("Seleccione un producto (si no hay ninguno, regístrelo primero).")
            cant = leer_entero(txt_venta_cant.value, "La cantidad")
            id_c = int(dd_venta_cli.value)
            id_p = int(dd_venta_prod.value)

            prod = next((p for p in producto_repo.obtener_productos() if p.id_producto == id_p), None)
            if prod is None:
                raise ValueError("El producto seleccionado ya no existe.")
            total = prod.precio * cant

            if editando is not None:
                producto_repo.actualizar_venta(Venta(editando.id_venta, id_c, id_p, cant, editando.fecha, total))
                mensaje = f"Venta #{editando.id_venta} actualizada. Nuevo total: ${total:,.2f}"
            else:
                fecha_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                producto_repo.registrar_venta(Venta(None, id_c, id_p, cant, fecha_actual, total))
                mensaje = f"¡Venta realizada con éxito! Total: ${total:,.2f}"
        except ErrorDeNegocio as ex:
            # Stock insuficiente, registro eliminado, etc.
            notificar(page, str(ex), "aviso")
            cargar_datos()
            return
        except ValueError as ex:
            notificar(page, str(ex), "error")
            return
        except Exception as ex:
            notificar(page, f"Error inesperado en la venta: {ex}", "error")
            return
        limpiar_form_venta()
        cargar_datos()
        notificar(page, mensaje)

    def pedir_eliminar_venta(v: Venta):
        def ejecutar():
            try:
                producto_repo.eliminar_venta(v.id_venta)
            except ErrorDeNegocio as ex:
                notificar(page, str(ex), "error")
                cargar_datos()
                return
            except Exception as ex:
                notificar(page, f"No se pudo eliminar la venta: {ex}", "error")
                return
            if edicion["venta"] == v:
                limpiar_form_venta()
            cargar_datos()
            notificar(page, "Venta eliminada y stock devuelto al inventario")

        confirmar(page, "Eliminar venta",
                  f"¿Eliminar la venta #{v.id_venta} por ${v.total:,.2f}?\n\n"
                  f"Las {v.cantidad} unidad(es) volverán al stock del producto.", ejecutar)

    btn_vender = ft.Button("Procesar Venta", on_click=guardar_venta, icon=ft.Icons.POINT_OF_SALE)
    btn_cancelar_venta = ft.OutlinedButton("Cancelar edición", on_click=limpiar_form_venta,
                                           icon=ft.Icons.CLOSE, visible=False)

    # ===================================================== CONTENEDORES / NAVEGACIÓN
    seccion_clientes = ft.Column([
        ft.Text("Registro de Clientes", size=20, weight=ft.FontWeight.BOLD),
        ft.Row([txt_cli_doc, txt_cli_nombre, txt_cli_tel, txt_cli_email], wrap=True),
        lbl_estado_cli,
        ft.Row([btn_guardar_cli, btn_cancelar_cli]),
        ft.Divider(),
        ft.Text("Lista de Clientes Registrados", size=16, weight=ft.FontWeight.BOLD),
        tabla_clientes
    ], scroll=ft.ScrollMode.AUTO, visible=True)

    seccion_productos = ft.Column([
        ft.Text("Gestión de Cómputo, Impresoras, Mouse y Celulares", size=20, weight=ft.FontWeight.BOLD),
        ft.Row([txt_prod_codigo, txt_prod_nombre, dd_prod_cat, txt_prod_precio, txt_prod_stock], wrap=True),
        lbl_estado_prod,
        ft.Row([btn_guardar_prod, btn_cancelar_prod]),
        ft.Divider(),
        ft.Text("Inventario Actual", size=16, weight=ft.FontWeight.BOLD),
        tabla_productos
    ], scroll=ft.ScrollMode.AUTO, visible=False)

    seccion_ventas = ft.Column([
        ft.Text("Módulo de Ventas y Facturación", size=20, weight=ft.FontWeight.BOLD),
        ft.Row([dd_venta_cli, dd_venta_prod, txt_venta_cant], wrap=True),
        lbl_estado_venta,
        ft.Row([btn_vender, btn_cancelar_venta]),
        ft.Divider(),
        ft.Text("Historial de Ventas", size=16, weight=ft.FontWeight.BOLD),
        tabla_ventas
    ], scroll=ft.ScrollMode.AUTO, visible=False)

    def cambiar_seccion(e):
        idx = e.control.selected_index
        seccion_clientes.visible = (idx == 0)
        seccion_productos.visible = (idx == 1)
        seccion_ventas.visible = (idx == 2)
        page.update()

    navegacion = ft.NavigationBar(
        selected_index=0,
        on_change=cambiar_seccion,
        destinations=[
            ft.NavigationBarDestination(icon=ft.Icons.PEOPLE, label="Clientes"),
            ft.NavigationBarDestination(icon=ft.Icons.COMPUTER, label="Inventario"),
            ft.NavigationBarDestination(icon=ft.Icons.POINT_OF_SALE, label="Ventas"),
        ]
    )

    page.add(
        ft.Text("TechStore - Sistema de Gestión Comercial", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE_400),
        navegacion,
        ft.Divider(),
        ft.Column([seccion_clientes, seccion_productos, seccion_ventas], expand=1)
    )
    cargar_datos()