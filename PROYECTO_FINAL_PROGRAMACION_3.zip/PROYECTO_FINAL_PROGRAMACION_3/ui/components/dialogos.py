from typing import Callable
import flet as ft

_COLORES = {
    "ok": ft.Colors.GREEN_700,
    "aviso": ft.Colors.ORANGE_800,
    "error": ft.Colors.RED_700,
}


def notificar(page: ft.Page, texto: str, tipo: str = "ok") -> None:
    """Muestra un mensaje temporal: tipo 'ok' (verde), 'aviso' (naranja) o 'error' (rojo)."""
    page.show_dialog(ft.SnackBar(ft.Text(texto), bgcolor=_COLORES.get(tipo, _COLORES["ok"])))


def confirmar(page: ft.Page, titulo: str, mensaje: str, on_confirmar: Callable[[], None],
              texto_boton: str = "Eliminar") -> None:
    """Muestra un diálogo de confirmación; ejecuta on_confirmar solo si el usuario acepta."""
    def aceptar(e):
        page.pop_dialog()
        on_confirmar()

    page.show_dialog(ft.AlertDialog(
        modal=True,
        title=ft.Text(titulo),
        content=ft.Text(mensaje),
        actions=[
            ft.TextButton("Cancelar", on_click=lambda e: page.pop_dialog()),
            ft.Button(texto_boton, icon=ft.Icons.DELETE, on_click=aceptar,
                      bgcolor=ft.Colors.RED_700, color=ft.Colors.WHITE),
        ],
    ))
