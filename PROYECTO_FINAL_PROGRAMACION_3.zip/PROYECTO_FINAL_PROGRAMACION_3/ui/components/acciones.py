from typing import Callable
import flet as ft


def celda_acciones(on_editar: Callable, on_eliminar: Callable) -> ft.DataCell:
    """Celda de tabla con los botones Editar y Eliminar de una fila."""
    return ft.DataCell(ft.Row([
        ft.IconButton(ft.Icons.EDIT, tooltip="Editar", icon_color=ft.Colors.BLUE_300, on_click=on_editar),
        ft.IconButton(ft.Icons.DELETE, tooltip="Eliminar", icon_color=ft.Colors.RED_400, on_click=on_eliminar),
    ], spacing=0))
