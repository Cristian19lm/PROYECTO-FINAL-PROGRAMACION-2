import math
from typing import Tuple, Any


class Producto:
    """Clase que representa un producto de tecnología (Computadores, Impresoras, Mouse, Celulares).

    id_producto -> llave primaria autoincremental (la asigna SQLite).
    codigo      -> identificador digitado por el usuario (SKU/referencia), único.
    """

    def __init__(self, id_producto: int | None, codigo: str, nombre: str, categoria: str, precio: float, stock: int):
        self.__id_producto = id_producto
        self.__codigo = (codigo or "").strip()
        self.__nombre = (nombre or "").strip()
        self.__categoria = (categoria or "").strip()
        self.__precio = float(precio)
        self.__stock = int(stock)

    @property
    def id_producto(self) -> int | None:
        return self.__id_producto

    @property
    def codigo(self) -> str:
        return self.__codigo

    @property
    def nombre(self) -> str:
        return self.__nombre

    @property
    def categoria(self) -> str:
        return self.__categoria

    @property
    def precio(self) -> float:
        return self.__precio

    @property
    def stock(self) -> int:
        return self.__stock

    def validar(self) -> None:
        """Lanza ValueError con un mensaje claro si algún dato no cumple las reglas."""
        if not self.__codigo:
            raise ValueError("El código del producto es obligatorio.")
        if not self.__nombre:
            raise ValueError("El nombre del producto es obligatorio.")
        if not self.__categoria:
            raise ValueError("Seleccione una categoría.")
        if not math.isfinite(self.__precio) or self.__precio <= 0:
            raise ValueError("El precio debe ser un número mayor que 0.")
        if self.__stock < 0:
            raise ValueError("El stock no puede ser negativo.")

    @classmethod
    def desde_tupla(cls, tupla: Tuple[Any, ...]) -> 'Producto':
        """Método de fábrica: (id_producto, codigo, nombre, categoria, precio, stock)."""
        return cls(id_producto=tupla[0], codigo=tupla[1], nombre=tupla[2],
                   categoria=tupla[3], precio=tupla[4], stock=tupla[5])

    def __str__(self) -> str:
        return f"[{self.__categoria}] {self.__codigo} - {self.__nombre} - ${self.__precio:,.2f} (Stock: {self.__stock})"

    def __repr__(self) -> str:
        return (f"Producto({self.__id_producto}, '{self.__codigo}', '{self.__nombre}', "
                f"'{self.__categoria}', {self.__precio}, {self.__stock})")

    def __len__(self) -> int:
        """Método mágico __len__ que retorna el stock disponible del producto."""
        return self.__stock

    def __eq__(self, otro: object) -> bool:
        if not isinstance(otro, Producto):
            return False
        return self.__id_producto == otro.__id_producto

    def __hash__(self) -> int:
        return hash(self.__id_producto)
