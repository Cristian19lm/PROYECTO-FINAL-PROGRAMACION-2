import re
from typing import Tuple, Any


class Cliente:
    """Clase que representa a un cliente de la tienda de cómputo.

    id_cliente  -> llave primaria autoincremental (la asigna SQLite).
    documento   -> identificador digitado por el usuario (cédula/NIT), único.
    """

    def __init__(self, id_cliente: int | None, documento: str, nombre: str, telefono: str, email: str = ""):
        self.__id_cliente = id_cliente
        self.__documento = (documento or "").strip()
        self.__nombre = (nombre or "").strip()
        self.__telefono = (telefono or "").strip()
        self.__email = (email or "").strip()

    @property
    def id_cliente(self) -> int | None:
        return self.__id_cliente

    @property
    def documento(self) -> str:
        return self.__documento

    @property
    def nombre(self) -> str:
        return self.__nombre

    @property
    def telefono(self) -> str:
        return self.__telefono

    @property
    def email(self) -> str:
        return self.__email

    def validar(self) -> None:
        """Lanza ValueError con un mensaje claro si algún dato no cumple las reglas."""
        if not self.__documento:
            raise ValueError("El documento / ID del cliente es obligatorio.")
        if not self.__nombre:
            raise ValueError("El nombre del cliente es obligatorio.")
        if sum(c.isdigit() for c in self.__telefono) < 7:
            raise ValueError("El teléfono es obligatorio y debe tener al menos 7 dígitos.")
        if self.__email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", self.__email):
            raise ValueError("El correo electrónico no tiene un formato válido.")

    @classmethod
    def desde_tupla(cls, tupla: Tuple[Any, ...]) -> 'Cliente':
        """Método de fábrica: (id_cliente, documento, nombre, telefono, email)."""
        return cls(id_cliente=tupla[0], documento=tupla[1], nombre=tupla[2], telefono=tupla[3], email=tupla[4])

    def __str__(self) -> str:
        return f"Cliente(ID: {self.__id_cliente}, Doc: {self.__documento}, Nombre: {self.__nombre}, Teléfono: {self.__telefono})"

    def __repr__(self) -> str:
        return f"Cliente({self.__id_cliente}, '{self.__documento}', '{self.__nombre}', '{self.__telefono}', '{self.__email}')"

    def __eq__(self, otro: object) -> bool:
        if not isinstance(otro, Cliente):
            return False
        return self.__id_cliente == otro.__id_cliente

    def __hash__(self) -> int:
        return hash(self.__id_cliente)
